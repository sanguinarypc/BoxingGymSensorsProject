#ifndef JSONHANDLER_H
#define JSONHANDLER_H

#include <Arduino.h>

class JsonHandler {
public:
  static void parseIncoming(const String &incoming);
};

#endif // JSONHANDLER_H
