#include "JsonHandler.h"
#include <ArduinoJson.h>

// 1) We must include <ArduinoIoTCloud.h> so the compiler knows
//    what CloudString and CloudInt actually are.
#include <ArduinoIoTCloud.h>

/*
  2) Instead of #include "thingProperties.h" (which would cause
  multiple definitions), we just declare the same variables as extern:
*/
extern CloudString deviceThatGotHit;
extern CloudString boxerThatScoresThePoint;
extern CloudInt    punchScore;
extern CloudString timeStampOfThePunch;
extern CloudInt    sensorValue;

extern CloudInt    blueBoxer_punchCount;
extern CloudString blueBoxer_timestamp;
extern CloudInt    blueBoxer_sensorValue;

extern CloudInt    redBoxer_punchCount;
extern CloudString redBoxer_timestamp;
extern CloudInt    redBoxer_sensorValue;

void JsonHandler::parseIncoming(const String &incoming) {
  StaticJsonDocument<256> doc;
  DeserializationError error = deserializeJson(doc, incoming);

  if (error) {
    Serial.print("JSON parse failed: ");
    Serial.println(error.f_str());
    return;
  }

  // Check for RoundStatusCommand
  if (doc.containsKey("RoundStatusCommand")) {
    int cmd = doc["RoundStatusCommand"]["Command"] | 0;
    if (cmd == 1) {
      // Reset all variables
      deviceThatGotHit        = "";
      boxerThatScoresThePoint = "";
      punchScore              = 0;
      timeStampOfThePunch     = "";
      sensorValue             = 0;

      blueBoxer_punchCount    = 0;
      blueBoxer_timestamp     = "";
      blueBoxer_sensorValue   = 0;

      redBoxer_punchCount     = 0;
      redBoxer_timestamp      = "";
      redBoxer_sensorValue    = 0;
      // Serial.println("RoundStatusCommand => All variables reset.");
    }
  } 
  else {
    // Parse usual fields
    const char* devStr   = doc["deviceStr"];
    const char* oppDev   = doc["oppositeDevice"];
    const char* punchStr = doc["punchCount"];
    const char* timeStr  = doc["timestamp"];
    const char* sensor   = doc["sensorValue"];

    deviceThatGotHit        = (devStr   != nullptr) ? String(devStr) : "";
    boxerThatScoresThePoint = (oppDev   != nullptr) ? String(oppDev) : "";
    punchScore              = (punchStr != nullptr) ? atoi(punchStr) : 0;
    timeStampOfThePunch     = (timeStr  != nullptr) ? String(timeStr) : "";
    sensorValue             = (sensor   != nullptr) ? atoi(sensor)    : 0;

    // Compare deviceStr and store to new boxer variables
    String deviceString = (devStr != nullptr) ? String(devStr) : "";

    if (deviceString == "RedBoxer") {
      blueBoxer_punchCount   = punchScore;
      blueBoxer_timestamp    = (timeStr != nullptr) ? String(timeStr) : "";
      blueBoxer_sensorValue  = (sensor  != nullptr) ? atoi(sensor)    : 0;
      // Serial.println("deviceStr = RedBoxer => Updating blueBoxer_ variables");
    }
    else if (deviceString == "BlueBoxer") {
      redBoxer_punchCount   = punchScore;
      redBoxer_timestamp    = (timeStr != nullptr) ? String(timeStr) : "";
      redBoxer_sensorValue  = (sensor  != nullptr) ? atoi(sensor)    : 0;
      // Serial.println("deviceStr = BlueBoxer => Updating redBoxer_ variables");
    }
  }
}
